# Lịch 24h – app Android quản lý thời gian theo từng phút

## Tính năng
- Xem cả ngày 24 giờ, **1 phút = 2dp** (1 giờ = 120dp), cuộn dọc.
- Thêm việc: bấm nút **+**, hoặc **chạm vào chỗ trống** trên lịch (tự điền giờ bắt đầu).
- Sửa / xóa việc: chạm vào khối việc.
- Giờ bắt đầu / kết thúc gõ chính xác từng phút.
- Việc trùng giờ tự chia cột cạnh nhau.
- Tô màu theo trạng thái:
  - Xanh lá: đã xong (gạch ngang tên)
  - Xanh dương: chưa làm (chưa đến giờ)
  - Cam: đang diễn ra
  - Đỏ: quá giờ mà chưa xong
- Bấm vòng tròn ở góc khối việc để đánh dấu xong / chưa xong.
- Thanh tiến độ "Đã xong x/y việc", đường đỏ chỉ giờ hiện tại.
- Chuyển ngày bằng ‹ Hôm nay ›.
- Thông báo: nhắc trước N phút (tùy chỉnh từng việc) và nhắc lại đúng giờ bắt đầu. Tự đặt lại sau khi khởi động lại máy.

## Cách chạy
1. Cài **Android Studio** (bản mới nhất).
2. Giải nén thư mục, chọn **File > Open** và mở thư mục `DayPlanner`.
3. Đợi Gradle sync xong (cần internet lần đầu). Nếu Android Studio gợi ý nâng cấp
   phiên bản Gradle / Android Gradle Plugin, cứ chọn đồng ý.
4. Cắm điện thoại (bật Gỡ lỗi USB) hoặc tạo máy ảo, bấm nút **Run ▶**.

## Tạo file APK để cài lên điện thoại
**Build > Build Bundle(s) / APK(s) > Build APK(s)**, file nằm ở
`app/build/outputs/apk/debug/app-debug.apk`.

## Cấu trúc mã
- `data/` – Room database (Task, TaskDao, AppDatabase)
- `reminder/` – đặt báo thức (AlarmManager), hiện thông báo, đặt lại sau khi khởi động máy
- `ui/PlannerScreen.kt` – giao diện lịch 24h
- `ui/TaskEditorDialog.kt` – hộp thoại thêm/sửa việc
- `ui/PlannerViewModel.kt` – xử lý dữ liệu
