package com.example.dayplanner.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.dayplanner.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

/** Sau khi khởi động lại máy, đặt lại báo thức cho các việc chưa làm. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val today = LocalDate.now().toEpochDay()
                AppDatabase.get(context).taskDao().upcoming(today).forEach {
                    ReminderScheduler.schedule(context, it)
                }
            } finally {
                pending.finish()
            }
        }
    }
}
