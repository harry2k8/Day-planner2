package com.example.dayplanner.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.dayplanner.data.AppDatabase
import com.example.dayplanner.data.Task
import com.example.dayplanner.reminder.ReminderScheduler
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class PlannerViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).taskDao()

    val date = MutableStateFlow(LocalDate.now())

    @OptIn(ExperimentalCoroutinesApi::class)
    val tasks: StateFlow<List<Task>> = date
        .flatMapLatest { dao.observeDay(it.toEpochDay()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun shiftDay(delta: Long) {
        date.value = date.value.plusDays(delta)
    }

    fun goToday() {
        date.value = LocalDate.now()
    }

    fun save(task: Task) {
        viewModelScope.launch {
            val id = if (task.id == 0L) {
                dao.insert(task)
            } else {
                dao.update(task)
                task.id
            }
            ReminderScheduler.schedule(getApplication(), task.copy(id = id))
        }
    }

    fun toggleDone(task: Task) = save(task.copy(done = !task.done))

    fun delete(task: Task) {
        viewModelScope.launch {
            dao.delete(task)
            ReminderScheduler.cancel(getApplication(), task.id)
        }
    }
}
