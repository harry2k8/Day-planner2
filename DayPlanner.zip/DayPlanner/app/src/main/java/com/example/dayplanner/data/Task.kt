package com.example.dayplanner.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Một việc trong ngày.
 * startMinute / endMinute: số phút tính từ 00:00 (0..1440).
 * remindBefore: nhắc trước bao nhiêu phút (0 = không nhắc trước).
 */
@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val note: String = "",
    val epochDay: Long,
    val startMinute: Int,
    val endMinute: Int,
    val done: Boolean = false,
    val remindBefore: Int = 10,
)
