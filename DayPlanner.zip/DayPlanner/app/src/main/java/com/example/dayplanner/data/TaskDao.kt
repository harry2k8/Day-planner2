package com.example.dayplanner.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks WHERE epochDay = :day ORDER BY startMinute")
    fun observeDay(day: Long): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE epochDay >= :fromDay AND done = 0")
    suspend fun upcoming(fromDay: Long): List<Task>

    @Insert
    suspend fun insert(task: Task): Long

    @Update
    suspend fun update(task: Task)

    @Delete
    suspend fun delete(task: Task)
}
