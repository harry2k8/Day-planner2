package com.example.dayplanner.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.dayplanner.data.Task
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

// 1 phút = 2dp  ->  1 giờ = 120dp  ->  cả ngày = 2880dp
private val MinuteHeight = 2.dp
private val HourHeight = MinuteHeight * 60

private val ColorDone = Color(0xFF2E7D32)      // xanh lá: đã xong
private val ColorDoing = Color(0xFFEF6C00)     // cam: đang diễn ra
private val ColorTodo = Color(0xFF1565C0)      // xanh dương: chưa làm
private val ColorOverdue = Color(0xFFC62828)   // đỏ: quá giờ mà chưa làm

private val viLocale: Locale = Locale.forLanguageTag("vi")

fun fmtTime(minute: Int): String = "%02d:%02d".format(minute / 60, minute % 60)

private fun currentMinute(): Int = LocalTime.now().let { it.hour * 60 + it.minute }

private fun statusColor(task: Task, date: LocalDate, nowMinute: Int): Color {
    val today = LocalDate.now()
    return when {
        task.done -> ColorDone
        date.isBefore(today) -> ColorOverdue
        date == today && nowMinute >= task.endMinute -> ColorOverdue
        date == today && nowMinute >= task.startMinute -> ColorDoing
        else -> ColorTodo
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerScreen(vm: PlannerViewModel = viewModel()) {
    val date by vm.date.collectAsState()
    val tasks by vm.tasks.collectAsState()
    var editor by remember { mutableStateOf<Task?>(null) }

    var nowMinute by remember { mutableIntStateOf(currentMinute()) }
    LaunchedEffect(Unit) {
        while (true) {
            nowMinute = currentMinute()
            delay(30_000)
        }
    }

    fun newTask(startMinute: Int): Task {
        val start = startMinute.coerceIn(0, 1439)
        return Task(
            title = "",
            epochDay = date.toEpochDay(),
            startMinute = start,
            endMinute = minOf(start + 60, 1440),
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            date.format(DateTimeFormatter.ofPattern("EEEE", viLocale)),
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                },
                actions = {
                    TextButton(onClick = { vm.shiftDay(-1) }) { Text("‹") }
                    TextButton(onClick = { vm.goToday() }) { Text("Hôm nay") }
                    TextButton(onClick = { vm.shiftDay(1) }) { Text("›") }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                val base = if (date == LocalDate.now()) nowMinute else 8 * 60
                editor = newTask(base / 5 * 5)
            }) {
                Icon(Icons.Default.Add, contentDescription = "Thêm việc")
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            val doneCount = tasks.count { it.done }
            if (tasks.isNotEmpty()) {
                Text(
                    "Đã xong $doneCount/${tasks.size} việc",
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                LinearProgressIndicator(
                    progress = { doneCount / tasks.size.toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }
            Legend()
            Timeline(
                modifier = Modifier.weight(1f),
                date = date,
                tasks = tasks,
                nowMinute = nowMinute,
                onTaskClick = { editor = it },
                onToggle = { vm.toggleDone(it) },
                onEmptyTap = { editor = newTask(it) },
            )
        }
    }

    editor?.let { current ->
        TaskEditorDialog(
            initial = current,
            isNew = current.id == 0L,
            onDismiss = { editor = null },
            onSave = {
                vm.save(it)
                editor = null
            },
            onDelete = if (current.id != 0L) {
                {
                    vm.delete(current)
                    editor = null
                }
            } else null
        )
    }
}

@Composable
private fun Legend() {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LegendItem(ColorDone, "Đã xong")
        LegendItem(ColorDoing, "Đang làm")
        LegendItem(ColorTodo, "Chưa làm")
        LegendItem(ColorOverdue, "Quá giờ")
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(" $label", fontSize = 11.sp)
    }
}

private data class Placed(val task: Task, val column: Int, val columns: Int)

/** Chia cột để các việc trùng giờ hiển thị cạnh nhau. */
private fun placeTasks(tasks: List<Task>): List<Placed> {
    val result = mutableListOf<Placed>()
    var cluster = mutableListOf<Task>()
    var clusterEnd = -1

    fun flush() {
        val columnEnds = mutableListOf<Int>()
        val assigned = cluster.map { t ->
            var c = columnEnds.indexOfFirst { it <= t.startMinute }
            if (c == -1) {
                columnEnds.add(t.endMinute)
                c = columnEnds.size - 1
            } else {
                columnEnds[c] = t.endMinute
            }
            t to c
        }
        assigned.forEach { (t, c) -> result.add(Placed(t, c, columnEnds.size)) }
        cluster = mutableListOf()
    }

    for (t in tasks.sortedBy { it.startMinute }) {
        if (cluster.isNotEmpty() && t.startMinute >= clusterEnd) {
            flush()
            clusterEnd = -1
        }
        cluster.add(t)
        clusterEnd = maxOf(clusterEnd, t.endMinute)
    }
    if (cluster.isNotEmpty()) flush()
    return result
}

@Composable
private fun Timeline(
    modifier: Modifier,
    date: LocalDate,
    tasks: List<Task>,
    nowMinute: Int,
    onTaskClick: (Task) -> Unit,
    onToggle: (Task) -> Unit,
    onEmptyTap: (Int) -> Unit,
) {
    val scroll = rememberScrollState()
    val density = LocalDensity.current
    val isToday = date == LocalDate.now()

    // Mở lên là cuộn tới giờ hiện tại (hoặc 6h sáng nếu không phải hôm nay)
    LaunchedEffect(date) {
        val targetMinute = if (isToday) (nowMinute - 60).coerceAtLeast(0) else 6 * 60
        scroll.scrollTo(with(density) { (MinuteHeight * targetMinute).roundToPx() })
    }

    Row(
        modifier
            .fillMaxWidth()
            .verticalScroll(scroll)
            .height(HourHeight * 24)
    ) {
        // Cột nhãn giờ
        Column(Modifier.width(52.dp)) {
            repeat(24) { h ->
                Box(Modifier.height(HourHeight)) {
                    Text(
                        "%02d:00".format(h),
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(start = 8.dp, top = 2.dp)
                    )
                }
            }
        }

        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxHeight()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val minute = (offset.y / MinuteHeight.toPx()).toInt() / 5 * 5
                        onEmptyTap(minute)
                    }
                }
        ) {
            val fullWidth = maxWidth

            // Đường kẻ giờ
            repeat(24) { h ->
                HorizontalDivider(Modifier.offset(y = HourHeight * h))
            }

            // Các việc
            for (p in placeTasks(tasks)) {
                val t = p.task
                val colWidth = fullWidth / p.columns
                val duration = (t.endMinute - t.startMinute).coerceAtLeast(10)
                TaskBlock(
                    task = t,
                    color = statusColor(t, date, nowMinute),
                    modifier = Modifier
                        .offset(x = colWidth * p.column, y = MinuteHeight * t.startMinute)
                        .size(colWidth, MinuteHeight * duration)
                        .padding(1.dp),
                    onClick = { onTaskClick(t) },
                    onToggle = { onToggle(t) },
                )
            }

            // Đường giờ hiện tại
            if (isToday) {
                Box(
                    Modifier
                        .offset(y = MinuteHeight * nowMinute)
                        .fillMaxWidth()
                        .height(2.dp)
                        .background(Color.Red)
                )
            }
        }
    }
}

@Composable
private fun TaskBlock(
    task: Task,
    color: Color,
    modifier: Modifier,
    onClick: () -> Unit,
    onToggle: () -> Unit,
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = color),
    ) {
        Row(
            Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                Modifier
                    .size(28.dp)
                    .clickable(onClick = onToggle),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (task.done) "✔" else "○",
                    color = Color.White,
                    fontSize = 18.sp
                )
            }
            Column(Modifier.padding(start = 2.dp)) {
                Text(
                    task.title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textDecoration = if (task.done) TextDecoration.LineThrough else null
                )
                Text(
                    "${fmtTime(task.startMinute)} – ${fmtTime(task.endMinute)}",
                    color = Color.White,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
        }
    }
}
