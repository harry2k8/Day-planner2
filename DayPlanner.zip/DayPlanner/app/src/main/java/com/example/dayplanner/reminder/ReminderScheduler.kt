package com.example.dayplanner.reminder

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.dayplanner.data.Task
import java.time.LocalDate
import java.time.ZoneId

object ReminderScheduler {
    const val CHANNEL_ID = "task_reminders"
    const val EXTRA_TITLE = "title"
    const val EXTRA_TEXT = "text"
    const val EXTRA_NOTIF_ID = "nid"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(
                        CHANNEL_ID,
                        "Nhắc việc",
                        NotificationManager.IMPORTANCE_HIGH
                    ).apply { description = "Thông báo sắp đến giờ làm việc" }
                )
            }
        }
    }

    /** Đặt lại toàn bộ báo thức của một việc (hủy cũ, đặt mới). */
    fun schedule(context: Context, task: Task) {
        cancel(context, task.id)
        if (task.done) return

        val start = LocalDate.ofEpochDay(task.epochDay)
            .atStartOfDay(ZoneId.systemDefault())
            .plusMinutes(task.startMinute.toLong())
            .toInstant()
            .toEpochMilli()
        val now = System.currentTimeMillis()

        if (task.remindBefore > 0) {
            val remindAt = start - task.remindBefore * 60_000L
            if (remindAt > now) {
                setAlarm(
                    context, remindAt, task.id, kind = 0,
                    title = task.title,
                    text = "Còn ${task.remindBefore} phút nữa là đến giờ"
                )
            }
        }
        if (start > now) {
            setAlarm(
                context, start, task.id, kind = 1,
                title = task.title,
                text = "Đến giờ làm rồi!"
            )
        }
    }

    fun cancel(context: Context, taskId: Long) {
        val am = context.getSystemService(AlarmManager::class.java)
        for (kind in 0..1) {
            am.cancel(buildPending(context, taskId, kind, "", ""))
        }
    }

    private fun setAlarm(
        context: Context,
        timeMillis: Long,
        taskId: Long,
        kind: Int,
        title: String,
        text: String,
    ) {
        val am = context.getSystemService(AlarmManager::class.java)
        val pi = buildPending(context, taskId, kind, title, text)
        val canExact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        if (canExact) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeMillis, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeMillis, pi)
        }
    }

    private fun buildPending(
        context: Context,
        taskId: Long,
        kind: Int,
        title: String,
        text: String,
    ): PendingIntent {
        val requestCode = (taskId * 2 + kind).toInt()
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_TEXT, text)
            putExtra(EXTRA_NOTIF_ID, requestCode)
        }
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
