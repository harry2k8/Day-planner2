package com.example.dayplanner.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimeInput
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.dayplanner.data.Task

@Composable
fun TaskEditorDialog(
    initial: Task,
    isNew: Boolean,
    onDismiss: () -> Unit,
    onSave: (Task) -> Unit,
    onDelete: (() -> Unit)?,
) {
    var title by remember { mutableStateOf(initial.title) }
    var note by remember { mutableStateOf(initial.note) }
    var start by remember { mutableIntStateOf(initial.startMinute) }
    var end by remember { mutableIntStateOf(initial.endMinute) }
    var remind by remember { mutableStateOf(initial.remindBefore.toString()) }
    var done by remember { mutableStateOf(initial.done) }
    var picking by remember { mutableIntStateOf(0) } // 0: không, 1: giờ bắt đầu, 2: giờ kết thúc

    val validTime = end > start

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "Việc mới" else "Sửa việc") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Tên việc") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { picking = 1 },
                        modifier = Modifier.weight(1f)
                    ) { Text("Từ ${fmtTime(start)}") }
                    OutlinedButton(
                        onClick = { picking = 2 },
                        modifier = Modifier.weight(1f)
                    ) { Text("Đến ${fmtTime(end)}") }
                }
                if (!validTime) {
                    Text(
                        "Giờ kết thúc phải sau giờ bắt đầu",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
                OutlinedTextField(
                    value = remind,
                    onValueChange = { v -> remind = v.filter { it.isDigit() }.take(4) },
                    label = { Text("Nhắc trước (phút, 0 = không)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Ghi chú") },
                    modifier = Modifier.fillMaxWidth()
                )
                if (!isNew) {
                    OutlinedButton(
                        onClick = { done = !done },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (done) "✔ Đã xong (bấm để bỏ đánh dấu)" else "○ Chưa xong (bấm để đánh dấu xong)") }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank() && validTime,
                onClick = {
                    onSave(
                        initial.copy(
                            title = title.trim(),
                            note = note.trim(),
                            startMinute = start,
                            endMinute = end,
                            remindBefore = remind.toIntOrNull() ?: 0,
                            done = done,
                        )
                    )
                }
            ) { Text("Lưu") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) { Text("Xóa") }
                }
                TextButton(onClick = onDismiss) { Text("Hủy") }
            }
        }
    )

    if (picking != 0) {
        TimePickDialog(
            initialMinute = if (picking == 1) start else end,
            onDismiss = { picking = 0 },
            onConfirm = { minute ->
                if (picking == 1) {
                    val duration = (end - start).takeIf { it > 0 } ?: 60
                    start = minute
                    end = minOf(minute + duration, 1440)
                } else {
                    end = minute
                }
                picking = 0
            }
        )
    }
}

/** Chọn giờ bằng cách gõ số (chính xác đến từng phút). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimePickDialog(
    initialMinute: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit,
) {
    val state = rememberTimePickerState(
        initialHour = (initialMinute / 60).coerceAtMost(23),
        initialMinute = initialMinute % 60,
        is24Hour = true
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onConfirm(state.hour * 60 + state.minute) }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } },
        text = { TimeInput(state = state) }
    )
}
